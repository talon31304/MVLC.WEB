﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LearnMVCBasics.Models
{
    public class MultiSessionAttendeeHours : SessionAttendee
    {
        public float hours { get; set; }

    }
}